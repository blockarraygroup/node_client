## ipfs-swarm-key-gen

This program generates swarm.key file for IPFS Private Network feature.

### Installation

```
go get -u github.com/Kubuxu/go-ipfs-swarm-key-gen/ipfs-swarm-key-gen
```

### Usage

```
ipfs-swarm-key-gen > ~/.ipfs/swarm.key
```

Change `~/.ipfs/` to different directory if you use custom IPFS_PATH.


### License

MIT
